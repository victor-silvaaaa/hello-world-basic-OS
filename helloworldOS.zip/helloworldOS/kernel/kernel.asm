[bits 32]
[org 0x1000]

start:
    mov ax, 0x10
    mov ds, ax
    mov ss, ax
    mov es, ax

    mov ebx, 0xB8000    ; video memory
    xor ecx, ecx        
mov byte [ebx], 0
mov ecx, 0
clean: 
    inc ecx
    mov byte[ebx + ecx], ''
    mov byte[ebx + ecx + 1], 0x0F
    cmp ecx, 5000       
    je mainmenu
    jne clean
cout:
   
mainmenu:
    mov byte [ebx + 0], 'H'
    mov byte [ebx + 1], 0x0F
    
    mov byte [ebx + 2], 'e'
    mov byte [ebx + 3], 0x0F
    
    mov byte [ebx + 4], 'l'
    mov byte [ebx + 5], 0x0F
    
    mov byte [ebx + 6], 'l'
    mov byte [ebx + 7], 0x0F
    
    mov byte [ebx + 8], 'o'
    mov byte [ebx + 9], 0x0F
    
    mov byte [ebx + 10], ' '
    mov byte [ebx + 11], 0x0F
    
    mov byte [ebx + 12], 'W'
    mov byte [ebx + 13], 0x0F
    
    mov byte [ebx + 14], 'o'
    mov byte [ebx + 15], 0x0F
    
    mov byte [ebx + 16], 'r'
    mov byte [ebx + 17], 0x0F
    
    mov byte [ebx + 18], 'l'
    mov byte [ebx + 19], 0x0F
    
    mov byte [ebx + 20], 'd'
    mov byte [ebx + 21], 0x0F

keyboard:
    in al, 0x60     

c:
    cmp al, 0x2E    
    jne main        
    
    mov byte [ebx + 22], 'C'
    mov byte [ebx + 23], 0x0A

main:
    jmp keyboard